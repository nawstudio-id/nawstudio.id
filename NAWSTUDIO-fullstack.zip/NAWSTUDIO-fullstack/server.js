const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY;
const MIDTRANS_CLIENT_KEY = process.env.MIDTRANS_CLIENT_KEY;
const MIDTRANS_BASE_URL = (process.env.MIDTRANS_BASE_URL || 'https://app.sandbox.midtrans.com').replace(/\/$/, '');

app.use(cors({ origin: true }));
app.use(express.json({ limit: '100kb' }));

const CATALOG = Object.freeze({
  'NAW-TSHIRT': { name: 'NAWSTUDIO T-Shirt', price: 65000 },
  'NAW-JERSEY': { name: 'NAWSTUDIO Custom Jersey', price: 249000 }
});

function midtransAuthHeader() {
  return `Basic ${Buffer.from(`${MIDTRANS_SERVER_KEY}:`).toString('base64')}`;
}

function makeOrderId() {
  return `NAW-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function normalizeItems(items) {
  if (!Array.isArray(items) || items.length === 0) {
    throw new Error('Keranjang kosong.');
  }

  return items.map((item) => {
    const id = String(item?.id || '');
    const product = CATALOG[id];
    if (!product) throw new Error(`Produk tidak valid: ${id || 'unknown'}`);

    const qty = Math.floor(Number(item?.quantity ?? item?.qty ?? 1));
    if (!Number.isInteger(qty) || qty < 1 || qty > 10000) {
      throw new Error('Jumlah produk tidak valid.');
    }
    if (id === 'NAW-JERSEY' && qty < 12) {
      throw new Error('Minimum custom jersey adalah 12 pcs.');
    }

    const name = String(item?.name || product.name).slice(0, 100);
    return {
      id,
      name,
      price: product.price,
      quantity: qty,
      subtotal: product.price * qty
    };
  });
}

app.get('/api/config', (_req, res) => {
  res.json({
    midtransClientKey: MIDTRANS_CLIENT_KEY || '',
    environment: MIDTRANS_BASE_URL.includes('app.midtrans.com') && !MIDTRANS_BASE_URL.includes('sandbox') ? 'production' : 'sandbox'
  });
});

app.post('/api/create-transaction', async (req, res) => {
  try {
    if (!MIDTRANS_SERVER_KEY) {
      return res.status(503).json({ error: 'MIDTRANS_SERVER_KEY belum dikonfigurasi di server.' });
    }

    const items = normalizeItems(req.body?.items);
    const grossAmount = items.reduce((sum, item) => sum + item.subtotal, 0);
    const orderId = makeOrderId();
    const customer = req.body?.customer || {};

    const payload = {
      transaction_details: {
        order_id: orderId,
        gross_amount: grossAmount
      },
      item_details: items.map(({ id, name, price, quantity }) => ({ id, name, price, quantity })),
      customer_details: {
        first_name: String(customer.first_name || 'Customer').slice(0, 50),
        email: customer.email ? String(customer.email).slice(0, 100) : undefined
      }
    };

    const response = await fetch(`${MIDTRANS_BASE_URL}/snap/v1/transactions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: midtransAuthHeader()
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error('Midtrans create transaction error:', data);
      return res.status(response.status).json({ error: data.status_message || 'Midtrans gagal membuat transaksi.' });
    }

    res.json({
      token: data.token,
      redirect_url: data.redirect_url,
      order_id: orderId,
      gross_amount: grossAmount
    });
  } catch (error) {
    console.error('Create transaction error:', error);
    res.status(400).json({ error: error.message || 'Gagal membuat transaksi.' });
  }
});

app.post('/api/midtrans-notification', (req, res) => {
  try {
    const notification = req.body || {};
    const { order_id, status_code, gross_amount, signature_key, transaction_status } = notification;

    if (!MIDTRANS_SERVER_KEY || !order_id || !status_code || !gross_amount || !signature_key) {
      return res.status(400).json({ error: 'Notifikasi tidak lengkap.' });
    }

    const expectedSignature = crypto
      .createHash('sha512')
      .update(`${order_id}${status_code}${gross_amount}${MIDTRANS_SERVER_KEY}`)
      .digest('hex');

    const valid = crypto.timingSafeEqual(
      Buffer.from(expectedSignature, 'utf8'),
      Buffer.from(String(signature_key), 'utf8')
    );

    if (!valid) return res.status(403).json({ error: 'Signature tidak valid.' });

    console.log(`[MIDTRANS] ${order_id}: ${transaction_status || 'unknown'}`);
    res.status(200).json({ ok: true });
  } catch (error) {
    console.error('Notification error:', error);
    res.status(400).json({ error: 'Notifikasi tidak valid.' });
  }
});

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'nawstudio-api' });
});

// Serve the website when this project is deployed to a Node-capable host.
app.use(express.static(path.join(__dirname)));

app.listen(PORT, () => {
  console.log(`NAWSTUDIO berjalan di port ${PORT}`);
  console.log(`Midtrans: ${MIDTRANS_BASE_URL}`);
});
