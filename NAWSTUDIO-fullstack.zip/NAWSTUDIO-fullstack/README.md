# NAWSTUDIO Website

Website NAWSTUDIO dengan Google Login (Firebase client-side) dan backend Node.js untuk Midtrans.

## Jalankan

1. Install Node.js 18+.
2. Jalankan `npm install`.
3. Salin `.env.example` menjadi `.env`.
4. Isi `MIDTRANS_SERVER_KEY` dan `MIDTRANS_CLIENT_KEY`.
5. Jalankan `npm start`.
6. Buka `http://localhost:3000`.

## Catatan

- `MIDTRANS_SERVER_KEY` hanya boleh disimpan di backend/.env, jangan dimasukkan ke index.html.
- Google Login tetap memakai Firebase di browser.
- QRIS muncul melalui Midtrans sesuai metode pembayaran yang aktif di akun Midtrans.
- Static.app hanya dapat menjalankan bagian HTML/CSS/JS statis. `server.js` harus dijalankan di hosting yang mendukung Node.js agar pembayaran Midtrans aktif.
