# NAWSTUDIO — Google Login + QRIS/Midtrans

## 1. Google Login
Website sudah disiapkan dengan Firebase Authentication + Google Sign-In.
Di `index.html`, ganti `firebaseConfig` dengan config project Firebase kamu.
Di Firebase Console:
- Authentication → Sign-in method → aktifkan Google.
- Tambahkan domain website kamu ke Authorized domains.

## 2. QRIS / Pembayaran
Checkout menggunakan Midtrans Snap. QRIS muncul di halaman pembayaran jika metode QRIS sudah aktif pada akun merchant Midtrans.
Server Key WAJIB disimpan di `.env`, jangan dimasukkan ke HTML atau GitHub.
Client Key boleh dipakai di frontend.

## 3. Jalankan
```bash
npm install
cp .env.example .env
# isi MIDTRANS_SERVER_KEY
npm start
```
Lalu buka `index.html` melalui hosting/web server, dan set `window.NAWSTUDIO_API_BASE` ke URL backend jika backend tidak berada di domain yang sama.

## 4. Penting
Versi ini memakai Midtrans Sandbox sebagai default. Untuk pembayaran asli, gunakan production credentials dan endpoint production setelah akun merchant siap.


## Catatan penting — Login Google
File ini sudah berisi kode Google Sign-In, tetapi kredensial Firebase adalah milik pemilik website, jadi saya tidak bisa membuat/menebak project Firebase milik kamu dari sini.

Setelah membuat Web App di Firebase, isi:
- `apiKey`
- `authDomain`
- `projectId`
- `storageBucket`
- `messagingSenderId`
- `appId`

Lalu aktifkan **Authentication → Sign-in method → Google** dan tambahkan domain website pada **Authorized domains**.
