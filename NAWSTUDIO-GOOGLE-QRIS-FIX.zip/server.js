const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY;
const MIDTRANS_BASE = process.env.MIDTRANS_BASE_URL || "https://app.sandbox.midtrans.com";

if (!MIDTRANS_SERVER_KEY) console.warn("MIDTRANS_SERVER_KEY belum diisi.");

app.post("/api/create-transaction", async (req, res) => {
  try {
    const { gross_amount, customer = {}, item = {} } = req.body;
    const amount = Number(gross_amount);
    if (!Number.isInteger(amount) || amount <= 0) {
      return res.status(400).json({ error: "gross_amount tidak valid" });
    }

    const order_id = "NAW-" + Date.now() + "-" + crypto.randomBytes(3).toString("hex");
    const auth = Buffer.from(MIDTRANS_SERVER_KEY + ":").toString("base64");

    const response = await fetch(MIDTRANS_BASE + "/snap/v1/transactions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Basic " + auth
      },
      body: JSON.stringify({
        transaction_details: { order_id, gross_amount: amount },
        item_details: [{
          id: item.id || "NAW-ITEM",
          price: Number(item.price) || amount,
          quantity: Number(item.quantity) || 1,
          name: item.name || "NAWSTUDIO"
        }],
        customer_details: {
          first_name: customer.first_name || "Customer",
          email: customer.email || undefined
        }
      })
    });

    const data = await response.json();
    if (!response.ok) return res.status(response.status).json(data);
    res.json({ token: data.token, redirect_url: data.redirect_url, order_id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal membuat transaksi." });
  }
});

app.post("/api/midtrans-notification", (req, res) => {
  // TODO: verifikasi signature_key + simpan status transaksi ke database.
  console.log("Midtrans notification:", req.body);
  res.status(200).json({ ok: true });
});

app.get("/health", (_, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`NAWSTUDIO API jalan di http://localhost:${PORT}`));
